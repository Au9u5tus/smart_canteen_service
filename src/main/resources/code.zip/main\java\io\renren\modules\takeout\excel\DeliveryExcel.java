package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class DeliveryExcel {
    @Excel(name = "配送ID")
    private String id;
    @Excel(name = "订单ID")
    private String orderId;
    @Excel(name = "配送人员ID")
    private String personId;
    @Excel(name = "配送开始时间")
    private String startTime;
    @Excel(name = "配送结束时间")
    private String endTime;
    @Excel(name = "配送状态")
    private String status;
    @Excel(name = "实际送餐地址")
    private String address;

}