package io.renren.modules.takeout.dao;

import io.renren.common.dao.BaseDao;
import io.renren.modules.takeout.entity.DeliveryEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Mapper
public interface DeliveryDao extends BaseDao<DeliveryEntity> {
	
}