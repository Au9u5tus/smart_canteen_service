package io.renren.modules.takeout.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.renren.common.service.impl.CrudServiceImpl;
import io.renren.modules.takeout.dao.EvaluationDao;
import io.renren.modules.takeout.dto.EvaluationDTO;
import io.renren.modules.takeout.entity.EvaluationEntity;
import io.renren.modules.takeout.service.EvaluationService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Service
public class EvaluationServiceImpl extends CrudServiceImpl<EvaluationDao, EvaluationEntity, EvaluationDTO> implements EvaluationService {

    @Override
    public QueryWrapper<EvaluationEntity> getWrapper(Map<String, Object> params){
        String id = (String)params.get("id");

        QueryWrapper<EvaluationEntity> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(id), "id", id);

        return wrapper;
    }


}