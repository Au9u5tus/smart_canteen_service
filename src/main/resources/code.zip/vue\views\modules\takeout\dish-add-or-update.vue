<template>
  <el-dialog :visible.sync="visible" :title="!dataForm.id ? $t('add') : $t('update')" :close-on-click-modal="false" :close-on-press-escape="false">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmitHandle()" :label-width="$i18n.locale === 'en-US' ? '120px' : '80px'">
          <el-form-item label="菜单名称" prop="name">
          <el-input v-model="dataForm.name" placeholder="菜单名称"></el-input>
      </el-form-item>
          <el-form-item label="菜单描述" prop="description">
          <el-input v-model="dataForm.description" placeholder="菜单描述"></el-input>
      </el-form-item>
          <el-form-item label="菜品价格" prop="price">
          <el-input v-model="dataForm.price" placeholder="菜品价格"></el-input>
      </el-form-item>
          <el-form-item label="菜品分类" prop="category">
          <el-input v-model="dataForm.category" placeholder="菜品分类"></el-input>
      </el-form-item>
          <el-form-item label="菜品主图的 URL" prop="imageUrlFirst">
          <el-input v-model="dataForm.imageUrlFirst" placeholder="菜品主图的 URL"></el-input>
      </el-form-item>
          <el-form-item label="菜品的第二张图" prop="imageUrlSecond">
          <el-input v-model="dataForm.imageUrlSecond" placeholder="菜品的第二张图"></el-input>
      </el-form-item>
          <el-form-item label="菜品的第三张图" prop="imageUrlThird">
          <el-input v-model="dataForm.imageUrlThird" placeholder="菜品的第三张图"></el-input>
      </el-form-item>
          <el-form-item label="菜品的第四张图" prop="imageUrlForth">
          <el-input v-model="dataForm.imageUrlForth" placeholder="菜品的第四张图"></el-input>
      </el-form-item>
          <el-form-item label="菜品是否可用" prop="available">
          <el-input v-model="dataForm.available" placeholder="菜品是否可用"></el-input>
      </el-form-item>
            <el-form-item label="菜品更新日期" prop="updateDate">
          <el-input v-model="dataForm.updateDate" placeholder="菜品更新日期"></el-input>
      </el-form-item>
      </el-form>
    <template slot="footer">
      <el-button @click="visible = false">{{ $t('cancel') }}</el-button>
      <el-button type="primary" @click="dataFormSubmitHandle()">{{ $t('confirm') }}</el-button>
    </template>
  </el-dialog>
</template>

<script>
import debounce from 'lodash/debounce'
export default {
  data () {
    return {
      visible: false,
      dataForm: {
        id: '',
        name: '',
        description: '',
        price: '',
        category: '',
        imageUrlFirst: '',
        imageUrlSecond: '',
        imageUrlThird: '',
        imageUrlForth: '',
        available: '',
        createDate: '',
        updateDate: ''
      }
    }
  },
  computed: {
    dataRule () {
      return {
        name: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        description: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        price: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        category: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        imageUrlFirst: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        imageUrlSecond: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        imageUrlThird: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        imageUrlForth: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        available: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        updateDate: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    init () {
      this.visible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].resetFields()
        if (this.dataForm.id) {
          this.getInfo()
        }
      })
    },
    // 获取信息
    getInfo () {
      this.$http.get(`/takeout/dish/${this.dataForm.id}`).then(({ data: res }) => {
        if (res.code !== 0) {
          return this.$message.error(res.msg)
        }
        this.dataForm = {
          ...this.dataForm,
          ...res.data
        }
      }).catch(() => {})
    },
    // 表单提交
    dataFormSubmitHandle: debounce(function () {
      this.$refs['dataForm'].validate((valid) => {
        if (!valid) {
          return false
        }
        this.$http[!this.dataForm.id ? 'post' : 'put']('/takeout/dish/', this.dataForm).then(({ data: res }) => {
          if (res.code !== 0) {
            return this.$message.error(res.msg)
          }
          this.$message({
            message: this.$t('prompt.success'),
            type: 'success',
            duration: 500,
            onClose: () => {
              this.visible = false
              this.$emit('refreshDataList')
            }
          })
        }).catch(() => {})
      })
    }, 1000, { 'leading': true, 'trailing': false })
  }
}
</script>
