<template>
  <el-dialog :visible.sync="visible" :title="!dataForm.id ? $t('add') : $t('update')" :close-on-click-modal="false" :close-on-press-escape="false">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmitHandle()" :label-width="$i18n.locale === 'en-US' ? '120px' : '80px'">
          <el-form-item label="学号" prop="studentId">
          <el-input v-model="dataForm.studentId" placeholder="学号"></el-input>
      </el-form-item>
          <el-form-item label="用户名" prop="username">
          <el-input v-model="dataForm.username" placeholder="用户名"></el-input>
      </el-form-item>
          <el-form-item label="密码" prop="password">
          <el-input v-model="dataForm.password" placeholder="密码"></el-input>
      </el-form-item>
          <el-form-item label="真实姓名" prop="name">
          <el-input v-model="dataForm.name" placeholder="真实姓名"></el-input>
      </el-form-item>
          <el-form-item label="性别" prop="gender">
          <el-input v-model="dataForm.gender" placeholder="性别"></el-input>
      </el-form-item>
          <el-form-item label="积分" prop="point">
          <el-input v-model="dataForm.point" placeholder="积分"></el-input>
      </el-form-item>
          <el-form-item label="联系电话" prop="phone">
          <el-input v-model="dataForm.phone" placeholder="联系电话"></el-input>
      </el-form-item>
          <el-form-item label="电子邮件地址" prop="email">
          <el-input v-model="dataForm.email" placeholder="电子邮件地址"></el-input>
      </el-form-item>
          <el-form-item label="头像" prop="avatar">
          <el-input v-model="dataForm.avatar" placeholder="头像"></el-input>
      </el-form-item>
          <el-form-item label="角色" prop="role">
          <el-input v-model="dataForm.role" placeholder="角色"></el-input>
      </el-form-item>
          <el-form-item label="注册系统的日期" prop="regDate">
          <el-input v-model="dataForm.regDate" placeholder="注册系统的日期"></el-input>
      </el-form-item>
          <el-form-item label="最后登录系统的时间" prop="lastLogin">
          <el-input v-model="dataForm.lastLogin" placeholder="最后登录系统的时间"></el-input>
      </el-form-item>
          <el-form-item label="用户账号的状态" prop="status">
          <el-input v-model="dataForm.status" placeholder="用户账号的状态"></el-input>
      </el-form-item>
      </el-form>
    <template slot="footer">
      <el-button @click="visible = false">{{ $t('cancel') }}</el-button>
      <el-button type="primary" @click="dataFormSubmitHandle()">{{ $t('confirm') }}</el-button>
    </template>
  </el-dialog>
</template>

<script>
import debounce from 'lodash/debounce'
export default {
  data () {
    return {
      visible: false,
      dataForm: {
        id: '',
        studentId: '',
        username: '',
        password: '',
        name: '',
        gender: '',
        point: '',
        phone: '',
        email: '',
        avatar: '',
        role: '',
        regDate: '',
        lastLogin: '',
        status: ''
      }
    }
  },
  computed: {
    dataRule () {
      return {
        studentId: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        username: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        password: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        name: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        gender: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        point: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        phone: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        email: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        avatar: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        role: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        regDate: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        lastLogin: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        status: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    init () {
      this.visible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].resetFields()
        if (this.dataForm.id) {
          this.getInfo()
        }
      })
    },
    // 获取信息
    getInfo () {
      this.$http.get(`/takeout/user/${this.dataForm.id}`).then(({ data: res }) => {
        if (res.code !== 0) {
          return this.$message.error(res.msg)
        }
        this.dataForm = {
          ...this.dataForm,
          ...res.data
        }
      }).catch(() => {})
    },
    // 表单提交
    dataFormSubmitHandle: debounce(function () {
      this.$refs['dataForm'].validate((valid) => {
        if (!valid) {
          return false
        }
        this.$http[!this.dataForm.id ? 'post' : 'put']('/takeout/user/', this.dataForm).then(({ data: res }) => {
          if (res.code !== 0) {
            return this.$message.error(res.msg)
          }
          this.$message({
            message: this.$t('prompt.success'),
            type: 'success',
            duration: 500,
            onClose: () => {
              this.visible = false
              this.$emit('refreshDataList')
            }
          })
        }).catch(() => {})
      })
    }, 1000, { 'leading': true, 'trailing': false })
  }
}
</script>
