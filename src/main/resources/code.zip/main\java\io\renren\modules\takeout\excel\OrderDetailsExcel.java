package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class OrderDetailsExcel {
    @Excel(name = "订单详情ID")
    private String id;
    @Excel(name = "订单ID")
    private String orderId;
    @Excel(name = "菜品ID")
    private String dishId;
    @Excel(name = "菜品订单中的数量")
    private Integer quantity;
    @Excel(name = "该菜品的单价")
    private Float unitPrice;
    @Excel(name = "该菜品的小计金额")
    private Float subTotal;

}