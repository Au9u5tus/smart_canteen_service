package io.renren.modules.takeout.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
@TableName("points")
public class PointsEntity {

    /**
     * 积分ID
     */
	private String id;
    /**
     * 用户ID
     */
	private String userId;
    /**
     * 积分数量
     */
	private Integer amount;
    /**
     * 积分交易类型
     */
	private String type;
    /**
     * 积分交易时间
     */
	private String time;
    /**
     * 订单ID
     */
	private Integer orderId;
}