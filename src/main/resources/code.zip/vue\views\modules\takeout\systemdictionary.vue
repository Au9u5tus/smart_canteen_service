<template>
  <el-card shadow="never" class="aui-card--fill">
    <div class="mod-takeout__systemdictionary}">
      <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
        <el-form-item>
          <el-input v-model="dataForm.dictionaryId" placeholder="dictionaryId" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-button @click="getDataList()">{{ $t('query') }}</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="info" @click="exportHandle()">{{ $t('export') }}</el-button>
        </el-form-item>
        <el-form-item>
          <el-button v-if="$hasPermission('takeout:systemdictionary:save')" type="primary" @click="addOrUpdateHandle()">{{ $t('add') }}</el-button>
        </el-form-item>
        <el-form-item>
          <el-button v-if="$hasPermission('takeout:systemdictionary:delete')" type="danger" @click="deleteHandle()">{{ $t('deleteBatch') }}</el-button>
        </el-form-item>
      </el-form>
      <el-table v-loading="dataListLoading" :data="dataList" border @selection-change="dataListSelectionChangeHandle" style="width: 100%;">
        <el-table-column type="selection" header-align="center" align="center" width="50"></el-table-column>
        <el-table-column prop="dictionaryId" label="字典的唯一标识符，作为主键" header-align="center" align="center"></el-table-column>
        <el-table-column prop="dictionaryType" label="字典类型，用于区分不同类型的字典项，如订单状态、支付方式、菜品分类等" header-align="center" align="center"></el-table-column>
        <el-table-column prop="dictionaryKey" label="字典项的键，唯一标识一个字典项，通常是一个简短的代码或名称" header-align="center" align="center"></el-table-column>
        <el-table-column prop="dictionaryValue" label="字典项的值，存储该字典项的具体内容或描述" header-align="center" align="center"></el-table-column>
        <el-table-column prop="displayOrder" label="显示顺序，用于控制字典项在界面上的显示顺序，数字越小越靠前" header-align="center" align="center"></el-table-column>
        <el-table-column prop="isEnabled" label="是否启用，用于标记该字典项是否可用，1 表示启用，0 表示禁用" header-align="center" align="center"></el-table-column>
        <el-table-column prop="createdAt" label="创建时间，记录字典项的创建时间，默认为当前时间戳" header-align="center" align="center"></el-table-column>
        <el-table-column prop="updatedAt" label="更新时间，记录字典项的最后更新时间，每次更新自动更新为当前时间戳" header-align="center" align="center"></el-table-column>
        <el-table-column :label="$t('handle')" fixed="right" header-align="center" align="center" width="150">
          <template slot-scope="scope">
            <el-button v-if="$hasPermission('takeout:systemdictionary:update')" type="text" size="small" @click="addOrUpdateHandle(scope.row.id)">{{ $t('update') }}</el-button>
            <el-button v-if="$hasPermission('takeout:systemdictionary:delete')" type="text" size="small" @click="deleteHandle(scope.row.id)">{{ $t('delete') }}</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        :current-page="page"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="limit"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="pageSizeChangeHandle"
        @current-change="pageCurrentChangeHandle">
      </el-pagination>
      <!-- 弹窗, 新增 / 修改 -->
      <add-or-update v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
    </div>
  </el-card>
</template>

<script>
import mixinViewModule from '@/mixins/view-module'
import AddOrUpdate from './systemdictionary-add-or-update'
export default {
  mixins: [mixinViewModule],
  data () {
    return {
      mixinViewModuleOptions: {
        getDataListURL: '/takeout/systemdictionary/page',
        getDataListIsPage: true,
        exportURL: '/takeout/systemdictionary/export',
        deleteURL: '/takeout/systemdictionary',
        deleteIsBatch: true
      },
      dataForm: {
        dictionaryId: ''
      }
    }
  },
  components: {
    AddOrUpdate
  }
}
</script>
