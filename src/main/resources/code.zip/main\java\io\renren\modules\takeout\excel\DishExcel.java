package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class DishExcel {
    @Excel(name = "菜单唯一标识符，作为主键")
    private String id;
    @Excel(name = "菜单名称")
    private String name;
    @Excel(name = "菜单描述")
    private String description;
    @Excel(name = "菜品价格")
    private Float price;
    @Excel(name = "菜品分类")
    private String category;
    @Excel(name = "菜品主图的 URL")
    private String imageUrlFirst;
    @Excel(name = "菜品的第二张图")
    private String imageUrlSecond;
    @Excel(name = "菜品的第三张图")
    private String imageUrlThird;
    @Excel(name = "菜品的第四张图")
    private String imageUrlForth;
    @Excel(name = "菜品是否可用")
    private Integer available;
    @Excel(name = "菜品创建日期")
    private String createDate;
    @Excel(name = "菜品更新日期")
    private String updateDate;

}