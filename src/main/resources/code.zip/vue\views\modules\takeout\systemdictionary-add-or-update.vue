<template>
  <el-dialog :visible.sync="visible" :title="!dataForm.dictionaryId ? $t('add') : $t('update')" :close-on-click-modal="false" :close-on-press-escape="false">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmitHandle()" :label-width="$i18n.locale === 'en-US' ? '120px' : '80px'">
          <el-form-item label="字典类型，用于区分不同类型的字典项，如订单状态、支付方式、菜品分类等" prop="dictionaryType">
          <el-input v-model="dataForm.dictionaryType" placeholder="字典类型，用于区分不同类型的字典项，如订单状态、支付方式、菜品分类等"></el-input>
      </el-form-item>
          <el-form-item label="字典项的键，唯一标识一个字典项，通常是一个简短的代码或名称" prop="dictionaryKey">
          <el-input v-model="dataForm.dictionaryKey" placeholder="字典项的键，唯一标识一个字典项，通常是一个简短的代码或名称"></el-input>
      </el-form-item>
          <el-form-item label="字典项的值，存储该字典项的具体内容或描述" prop="dictionaryValue">
          <el-input v-model="dataForm.dictionaryValue" placeholder="字典项的值，存储该字典项的具体内容或描述"></el-input>
      </el-form-item>
          <el-form-item label="显示顺序，用于控制字典项在界面上的显示顺序，数字越小越靠前" prop="displayOrder">
          <el-input v-model="dataForm.displayOrder" placeholder="显示顺序，用于控制字典项在界面上的显示顺序，数字越小越靠前"></el-input>
      </el-form-item>
          <el-form-item label="是否启用，用于标记该字典项是否可用，1 表示启用，0 表示禁用" prop="isEnabled">
          <el-input v-model="dataForm.isEnabled" placeholder="是否启用，用于标记该字典项是否可用，1 表示启用，0 表示禁用"></el-input>
      </el-form-item>
          <el-form-item label="创建时间，记录字典项的创建时间，默认为当前时间戳" prop="createdAt">
          <el-input v-model="dataForm.createdAt" placeholder="创建时间，记录字典项的创建时间，默认为当前时间戳"></el-input>
      </el-form-item>
          <el-form-item label="更新时间，记录字典项的最后更新时间，每次更新自动更新为当前时间戳" prop="updatedAt">
          <el-input v-model="dataForm.updatedAt" placeholder="更新时间，记录字典项的最后更新时间，每次更新自动更新为当前时间戳"></el-input>
      </el-form-item>
      </el-form>
    <template slot="footer">
      <el-button @click="visible = false">{{ $t('cancel') }}</el-button>
      <el-button type="primary" @click="dataFormSubmitHandle()">{{ $t('confirm') }}</el-button>
    </template>
  </el-dialog>
</template>

<script>
import debounce from 'lodash/debounce'
export default {
  data () {
    return {
      visible: false,
      dataForm: {
        dictionaryId: '',
        dictionaryType: '',
        dictionaryKey: '',
        dictionaryValue: '',
        displayOrder: '',
        isEnabled: '',
        createdAt: '',
        updatedAt: ''
      }
    }
  },
  computed: {
    dataRule () {
      return {
        dictionaryType: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        dictionaryKey: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        dictionaryValue: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        displayOrder: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        isEnabled: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        createdAt: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        updatedAt: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    init () {
      this.visible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].resetFields()
        if (this.dataForm.dictionaryId) {
          this.getInfo()
        }
      })
    },
    // 获取信息
    getInfo () {
      this.$http.get(`/takeout/systemdictionary/${this.dataForm.dictionaryId}`).then(({ data: res }) => {
        if (res.code !== 0) {
          return this.$message.error(res.msg)
        }
        this.dataForm = {
          ...this.dataForm,
          ...res.data
        }
      }).catch(() => {})
    },
    // 表单提交
    dataFormSubmitHandle: debounce(function () {
      this.$refs['dataForm'].validate((valid) => {
        if (!valid) {
          return false
        }
        this.$http[!this.dataForm.dictionaryId ? 'post' : 'put']('/takeout/systemdictionary/', this.dataForm).then(({ data: res }) => {
          if (res.code !== 0) {
            return this.$message.error(res.msg)
          }
          this.$message({
            message: this.$t('prompt.success'),
            type: 'success',
            duration: 500,
            onClose: () => {
              this.visible = false
              this.$emit('refreshDataList')
            }
          })
        }).catch(() => {})
      })
    }, 1000, { 'leading': true, 'trailing': false })
  }
}
</script>
