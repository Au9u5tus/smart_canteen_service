<template>
  <el-dialog :visible.sync="visible" :title="!dataForm.id ? $t('add') : $t('update')" :close-on-click-modal="false" :close-on-press-escape="false">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmitHandle()" :label-width="$i18n.locale === 'en-US' ? '120px' : '80px'">
          <el-form-item label="用户ID" prop="userId">
          <el-input v-model="dataForm.userId" placeholder="用户ID"></el-input>
      </el-form-item>
          <el-form-item label="菜品ID" prop="dishId">
          <el-input v-model="dataForm.dishId" placeholder="菜品ID"></el-input>
      </el-form-item>
          <el-form-item label="菜品的数量" prop="quantity">
          <el-input v-model="dataForm.quantity" placeholder="菜品的数量"></el-input>
      </el-form-item>
          <el-form-item label="订单生成时间" prop="orderTime">
          <el-input v-model="dataForm.orderTime" placeholder="订单生成时间"></el-input>
      </el-form-item>
          <el-form-item label="订单的总价" prop="totalPrice">
          <el-input v-model="dataForm.totalPrice" placeholder="订单的总价"></el-input>
      </el-form-item>
          <el-form-item label="订单状态" prop="status">
          <el-input v-model="dataForm.status" placeholder="订单状态"></el-input>
      </el-form-item>
          <el-form-item label="支付方式" prop="payMethod">
          <el-input v-model="dataForm.payMethod" placeholder="支付方式"></el-input>
      </el-form-item>
          <el-form-item label="送餐地址" prop="address">
          <el-input v-model="dataForm.address" placeholder="送餐地址"></el-input>
      </el-form-item>
          <el-form-item label="预计送餐时间" prop="delTime">
          <el-input v-model="dataForm.delTime" placeholder="预计送餐时间"></el-input>
      </el-form-item>
          <el-form-item label="送餐状态" prop="delStatus">
          <el-input v-model="dataForm.delStatus" placeholder="送餐状态"></el-input>
      </el-form-item>
      </el-form>
    <template slot="footer">
      <el-button @click="visible = false">{{ $t('cancel') }}</el-button>
      <el-button type="primary" @click="dataFormSubmitHandle()">{{ $t('confirm') }}</el-button>
    </template>
  </el-dialog>
</template>

<script>
import debounce from 'lodash/debounce'
export default {
  data () {
    return {
      visible: false,
      dataForm: {
        id: '',
        userId: '',
        dishId: '',
        quantity: '',
        orderTime: '',
        totalPrice: '',
        status: '',
        payMethod: '',
        address: '',
        delTime: '',
        delStatus: ''
      }
    }
  },
  computed: {
    dataRule () {
      return {
        userId: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        dishId: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        quantity: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        orderTime: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        totalPrice: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        status: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        payMethod: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        address: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        delTime: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ],
        delStatus: [
          { required: true, message: this.$t('validate.required'), trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    init () {
      this.visible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].resetFields()
        if (this.dataForm.id) {
          this.getInfo()
        }
      })
    },
    // 获取信息
    getInfo () {
      this.$http.get(`/takeout/orders/${this.dataForm.id}`).then(({ data: res }) => {
        if (res.code !== 0) {
          return this.$message.error(res.msg)
        }
        this.dataForm = {
          ...this.dataForm,
          ...res.data
        }
      }).catch(() => {})
    },
    // 表单提交
    dataFormSubmitHandle: debounce(function () {
      this.$refs['dataForm'].validate((valid) => {
        if (!valid) {
          return false
        }
        this.$http[!this.dataForm.id ? 'post' : 'put']('/takeout/orders/', this.dataForm).then(({ data: res }) => {
          if (res.code !== 0) {
            return this.$message.error(res.msg)
          }
          this.$message({
            message: this.$t('prompt.success'),
            type: 'success',
            duration: 500,
            onClose: () => {
              this.visible = false
              this.$emit('refreshDataList')
            }
          })
        }).catch(() => {})
      })
    }, 1000, { 'leading': true, 'trailing': false })
  }
}
</script>
