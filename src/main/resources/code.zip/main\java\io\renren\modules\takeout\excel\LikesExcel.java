package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class LikesExcel {
    @Excel(name = "点赞ID")
    private String id;
    @Excel(name = "用户ID")
    private String userId;
    @Excel(name = "菜单ID")
    private String dishId;
    @Excel(name = "点赞时间")
    private String likedTime;

}