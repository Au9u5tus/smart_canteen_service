<template>
  <el-card shadow="never" class="aui-card--fill">
    <div class="mod-takeout__dish}">
      <el-form :inline="true" :model="dataForm" @keyup.enter.native="getDataList()">
        <el-form-item>
          <el-input v-model="dataForm.id" placeholder="id" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-button @click="getDataList()">{{ $t('query') }}</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="info" @click="exportHandle()">{{ $t('export') }}</el-button>
        </el-form-item>
        <el-form-item>
          <el-button v-if="$hasPermission('takeout:dish:save')" type="primary" @click="addOrUpdateHandle()">{{ $t('add') }}</el-button>
        </el-form-item>
        <el-form-item>
          <el-button v-if="$hasPermission('takeout:dish:delete')" type="danger" @click="deleteHandle()">{{ $t('deleteBatch') }}</el-button>
        </el-form-item>
      </el-form>
      <el-table v-loading="dataListLoading" :data="dataList" border @selection-change="dataListSelectionChangeHandle" style="width: 100%;">
        <el-table-column type="selection" header-align="center" align="center" width="50"></el-table-column>
        <el-table-column prop="id" label="菜单唯一标识符，作为主键" header-align="center" align="center"></el-table-column>
        <el-table-column prop="name" label="菜单名称" header-align="center" align="center"></el-table-column>
        <el-table-column prop="description" label="菜单描述" header-align="center" align="center"></el-table-column>
        <el-table-column prop="price" label="菜品价格" header-align="center" align="center"></el-table-column>
        <el-table-column prop="category" label="菜品分类" header-align="center" align="center"></el-table-column>
        <el-table-column prop="imageUrlFirst" label="菜品主图的 URL" header-align="center" align="center"></el-table-column>
        <el-table-column prop="imageUrlSecond" label="菜品的第二张图" header-align="center" align="center"></el-table-column>
        <el-table-column prop="imageUrlThird" label="菜品的第三张图" header-align="center" align="center"></el-table-column>
        <el-table-column prop="imageUrlForth" label="菜品的第四张图" header-align="center" align="center"></el-table-column>
        <el-table-column prop="available" label="菜品是否可用" header-align="center" align="center"></el-table-column>
        <el-table-column prop="createDate" label="菜品创建日期" header-align="center" align="center"></el-table-column>
        <el-table-column prop="updateDate" label="菜品更新日期" header-align="center" align="center"></el-table-column>
        <el-table-column :label="$t('handle')" fixed="right" header-align="center" align="center" width="150">
          <template slot-scope="scope">
            <el-button v-if="$hasPermission('takeout:dish:update')" type="text" size="small" @click="addOrUpdateHandle(scope.row.id)">{{ $t('update') }}</el-button>
            <el-button v-if="$hasPermission('takeout:dish:delete')" type="text" size="small" @click="deleteHandle(scope.row.id)">{{ $t('delete') }}</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        :current-page="page"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="limit"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="pageSizeChangeHandle"
        @current-change="pageCurrentChangeHandle">
      </el-pagination>
      <!-- 弹窗, 新增 / 修改 -->
      <add-or-update v-if="addOrUpdateVisible" ref="addOrUpdate" @refreshDataList="getDataList"></add-or-update>
    </div>
  </el-card>
</template>

<script>
import mixinViewModule from '@/mixins/view-module'
import AddOrUpdate from './dish-add-or-update'
export default {
  mixins: [mixinViewModule],
  data () {
    return {
      mixinViewModuleOptions: {
        getDataListURL: '/takeout/dish/page',
        getDataListIsPage: true,
        exportURL: '/takeout/dish/export',
        deleteURL: '/takeout/dish',
        deleteIsBatch: true
      },
      dataForm: {
        id: ''
      }
    }
  },
  components: {
    AddOrUpdate
  }
}
</script>
