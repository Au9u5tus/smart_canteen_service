package io.renren.modules.takeout.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
@TableName("user")
public class UserEntity {

    /**
     * 用户ID
     */
	private String id;
    /**
     * 学号
     */
	private String studentId;
    /**
     * 用户名
     */
	private String username;
    /**
     * 密码
     */
	private String password;
    /**
     * 真实姓名
     */
	private String name;
    /**
     * 性别
     */
	private String gender;
    /**
     * 积分
     */
	private Integer point;
    /**
     * 联系电话
     */
	private String phone;
    /**
     * 电子邮件地址
     */
	private String email;
    /**
     * 头像
     */
	private String avatar;
    /**
     * 角色
     */
	private String role;
    /**
     * 注册系统的日期
     */
	private String regDate;
    /**
     * 最后登录系统的时间
     */
	private String lastLogin;
    /**
     * 用户账号的状态
     */
	private String status;
}