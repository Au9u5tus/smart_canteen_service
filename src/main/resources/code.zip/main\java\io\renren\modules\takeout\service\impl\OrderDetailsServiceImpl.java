package io.renren.modules.takeout.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.renren.common.service.impl.CrudServiceImpl;
import io.renren.modules.takeout.dao.OrderDetailsDao;
import io.renren.modules.takeout.dto.OrderDetailsDTO;
import io.renren.modules.takeout.entity.OrderDetailsEntity;
import io.renren.modules.takeout.service.OrderDetailsService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Service
public class OrderDetailsServiceImpl extends CrudServiceImpl<OrderDetailsDao, OrderDetailsEntity, OrderDetailsDTO> implements OrderDetailsService {

    @Override
    public QueryWrapper<OrderDetailsEntity> getWrapper(Map<String, Object> params){
        String id = (String)params.get("id");

        QueryWrapper<OrderDetailsEntity> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(id), "id", id);

        return wrapper;
    }


}