package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class OrdersExcel {
    @Excel(name = "订单ID")
    private String id;
    @Excel(name = "用户ID")
    private String userId;
    @Excel(name = "菜品ID")
    private String dishId;
    @Excel(name = "菜品的数量")
    private Integer quantity;
    @Excel(name = "订单生成时间")
    private String orderTime;
    @Excel(name = "订单的总价")
    private Float totalPrice;
    @Excel(name = "订单状态")
    private String status;
    @Excel(name = "支付方式")
    private String payMethod;
    @Excel(name = "送餐地址")
    private String address;
    @Excel(name = "预计送餐时间")
    private String delTime;
    @Excel(name = "送餐状态")
    private String delStatus;

}