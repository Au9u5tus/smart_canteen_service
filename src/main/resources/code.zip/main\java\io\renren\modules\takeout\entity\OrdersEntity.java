package io.renren.modules.takeout.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
@TableName("orders")
public class OrdersEntity {

    /**
     * 订单ID
     */
	private String id;
    /**
     * 用户ID
     */
	private String userId;
    /**
     * 菜品ID
     */
	private String dishId;
    /**
     * 菜品的数量
     */
	private Integer quantity;
    /**
     * 订单生成时间
     */
	private String orderTime;
    /**
     * 订单的总价
     */
	private Float totalPrice;
    /**
     * 订单状态
     */
	private String status;
    /**
     * 支付方式
     */
	private String payMethod;
    /**
     * 送餐地址
     */
	private String address;
    /**
     * 预计送餐时间
     */
	private String delTime;
    /**
     * 送餐状态
     */
	private String delStatus;
}