package io.renren.modules.takeout.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import io.renren.common.service.impl.CrudServiceImpl;
import io.renren.modules.takeout.dao.LikesDao;
import io.renren.modules.takeout.dto.LikesDTO;
import io.renren.modules.takeout.entity.LikesEntity;
import io.renren.modules.takeout.service.LikesService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Service
public class LikesServiceImpl extends CrudServiceImpl<LikesDao, LikesEntity, LikesDTO> implements LikesService {

    @Override
    public QueryWrapper<LikesEntity> getWrapper(Map<String, Object> params){
        String id = (String)params.get("id");

        QueryWrapper<LikesEntity> wrapper = new QueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(id), "id", id);

        return wrapper;
    }


}