package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class UserExcel {
    @Excel(name = "用户ID")
    private String id;
    @Excel(name = "学号")
    private String studentId;
    @Excel(name = "用户名")
    private String username;
    @Excel(name = "密码")
    private String password;
    @Excel(name = "真实姓名")
    private String name;
    @Excel(name = "性别")
    private String gender;
    @Excel(name = "积分")
    private Integer point;
    @Excel(name = "联系电话")
    private String phone;
    @Excel(name = "电子邮件地址")
    private String email;
    @Excel(name = "头像")
    private String avatar;
    @Excel(name = "角色")
    private String role;
    @Excel(name = "注册系统的日期")
    private String regDate;
    @Excel(name = "最后登录系统的时间")
    private String lastLogin;
    @Excel(name = "用户账号的状态")
    private String status;

}