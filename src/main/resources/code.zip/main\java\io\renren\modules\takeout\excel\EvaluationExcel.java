package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class EvaluationExcel {
    @Excel(name = "评价ID")
    private String id;
    @Excel(name = "菜品ID")
    private String dishId;
    @Excel(name = "用户ID")
    private String userId;
    @Excel(name = "评分")
    private Integer rating;
    @Excel(name = "用户的评论内容")
    private String comment;
    @Excel(name = "评价时间")
    private String evalTime;

}