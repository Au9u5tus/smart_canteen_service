package io.renren.modules.takeout.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
@TableName("likes")
public class LikesEntity {

    /**
     * 点赞ID
     */
	private String id;
    /**
     * 用户ID
     */
	private String userId;
    /**
     * 菜单ID
     */
	private String dishId;
    /**
     * 点赞时间
     */
	private String likedTime;
}