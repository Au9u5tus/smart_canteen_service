package io.renren.modules.takeout.excel;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 
 *
 * @author David 321740709@qq.com
 * @since 1.0.0 2025-01-27
 */
@Data
public class PointsExcel {
    @Excel(name = "积分ID")
    private String id;
    @Excel(name = "用户ID")
    private String userId;
    @Excel(name = "积分数量")
    private Integer amount;
    @Excel(name = "积分交易类型")
    private String type;
    @Excel(name = "积分交易时间")
    private String time;
    @Excel(name = "订单ID")
    private Integer orderId;

}